﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Spiral_ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Generate an array of number 0 to n
             * Assign location of numbers starting at center. 
             * Center will be that of a 3,5,7,9,
             * Take the mod of sqrt of n if / 2 has remainder mod it and add 1
             * that gives max of x and y 
             * add 1 and divide by 2 and that gives the center x,y
             * 
             * 
             * Directions
             *  x,y if R add 1 to x if D add 1 y if L subtract 1 from x if up subtract 1 from Y
             *  
             * 
             *  
             */

            Console.WriteLine("Enter a wholenumber value between 1 and 256");
            String input = Console.ReadLine();

            Int32 n;
            if (!Int32.TryParse(input, out n) && !(n>=1 && n<=256))
            {
                n = 256;
                Console.WriteLine("You have failed to follow instrucations.. running for 256");
            }



            Int32 directionChangeCount = 0; //reset at 2 and increment the step count
            Int32 directionCurrent = 1; //move right
            Int32 stepCount = 0; //will increase by one every other direction change
            Int32 stepCountLimit = 1;
            Int32 currentX;
            Int32 currentY;

            Int32 maxDimension = (Int32)Math.Truncate(Math.Sqrt(n));

            if (Math.Sqrt(n) - Math.Truncate(Math.Sqrt(n)) > 0)
            {
                maxDimension++;
            }

            //only want to deal with squares
            if (!(maxDimension % 2 > 0))
            {
                maxDimension++;
            }

            String[,] arrayOfNummbers = new String[maxDimension, maxDimension];

            //determine center
            currentX = (maxDimension + 1)/2 ;
            currentY = (maxDimension + 1)/2; ;
            arrayOfNummbers[(currentX-1), (currentY-1)] = "0";

            Int32 i = 1;

            #region Outer Loop
            while(i <= (n-2))
            {
                //Write out RDLU 
                //Direciton change every
                //R D LL UU RRR DDD LLLL UUUU RRRRR
                directionChangeCount = 1;
                #region Inner Loop
                while (directionChangeCount <= 2)
                {
                   stepCount = 1;
                   #region Inner Most Loop
                   while (stepCount <= stepCountLimit)
                   {
                       stepCount++;
                       switch (directionCurrent)
                       {
                           case 1: //R
                               {
                                   currentX++;   
                                   break;
                               }
                           case 2: //D
                               {
                                   currentY++; 
                                   break;
                               }
                           case 3: //L
                               {
                                   currentX--; 
                                   break;
                               }
                           case 4: //U
                               {
                                   currentY--; 
                                   break;
                               }
                       }
                       //Write to array
                       arrayOfNummbers[(currentX - 1), (currentY - 1)] = i.ToString();                       
                       if (i > (n-1))
                       {
                           break;
                       }
                       Console.WriteLine(String.Format("{0}-{1}-{2}-{3}",i,directionCurrent.ToString(),currentX,currentY));
                       i++;

                   }
                   
                   directionChangeCount++;
                   if (directionCurrent == 4)
                   {
                       directionCurrent = 1;
                   }
                   else
                   {
                       directionCurrent++;
                   }
                   #endregion
                }
                #endregion
                stepCountLimit++;
            }
            #endregion

            #region Display Results
            for (Int32 rowNum = 0; rowNum <= (maxDimension -1); rowNum++)
            {
                StringBuilder row = new StringBuilder();
                for (Int32 colNum = 0; colNum <= (maxDimension -1); colNum++)
                { 
                    row.Append(String.Format("\t[{0}]",arrayOfNummbers[colNum,rowNum]));
                }
                Console.WriteLine(row.ToString());
            }
            #endregion

            Console.ReadKey(true);
        }
    }
}
